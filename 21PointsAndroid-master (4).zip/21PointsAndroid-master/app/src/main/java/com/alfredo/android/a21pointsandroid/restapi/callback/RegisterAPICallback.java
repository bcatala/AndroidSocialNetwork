package com.alfredo.android.a21pointsandroid.restapi.callback;

import com.alfredo.android.a21pointsandroid.restapi.callback.RestAPICallBack;

public interface RegisterAPICallback extends RestAPICallBack {
    void onSuccess();
}