package com.alfredo.android.a21pointsandroid.restapi.callback;

public interface RestAPICallBack {
    void onFailure(Throwable t);
}